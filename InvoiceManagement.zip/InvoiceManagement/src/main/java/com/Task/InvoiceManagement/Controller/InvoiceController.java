package com.Task.InvoiceManagement.Controller;


import com.Task.InvoiceManagement.Services.InvoiceService;
import com.Task.InvoiceManagement.models.Contact;
import com.Task.InvoiceManagement.models.Invoice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InvoiceController {

    @Autowired
    InvoiceService invoiceService;

    @PostMapping("/invoices")
    public void createInvoice(@RequestParam("Itemid") int itemId, @RequestParam("contactEmail") String contactEmail, @RequestBody Invoice invoice) throws Exception{
        invoiceService.addInvoice(itemId,contactEmail,invoice);

    }


}
