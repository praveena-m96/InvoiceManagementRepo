package com.Task.InvoiceManagement.Controller;

import com.Task.InvoiceManagement.Request.ItemCreateRequest;
import com.Task.InvoiceManagement.Services.ItemService;
import com.Task.InvoiceManagement.models.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class ItemController {

    @Autowired
    ItemService itemService;

    @PostMapping("/item")
    public void createItem(@RequestBody ItemCreateRequest itemCreateRequest){
        itemService.addItem(itemCreateRequest);

    }

    @GetMapping("/item")
    public Item getItem(@RequestParam("id") int id ) throws Exception {
        return itemService.getItemByID(id);
    }
}
