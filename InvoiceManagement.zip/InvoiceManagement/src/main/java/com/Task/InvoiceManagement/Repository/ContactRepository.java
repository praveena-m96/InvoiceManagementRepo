package com.Task.InvoiceManagement.Repository;

import com.Task.InvoiceManagement.models.Contact;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ContactRepository extends JpaRepository<Contact,Integer> {

    @Query("from Contact where contactEmail= :contactEmail")
    Contact findByContactEmail(String contactEmail);

}