package com.Task.InvoiceManagement.Request;

import com.Task.InvoiceManagement.models.Item;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class ItemCreateRequest {

    private String itemName;
    private double itemPrice;
    private int quantity;
    private String contactEmail;
    private String contactName;
    private String contactCompany;
    private String contactAddress;
    private String vendorName;
    private String vendorCompany;
    private String vendorAddress;
    private String contactNumber;


    public double getTotalPrice() {
        return quantity * itemPrice;
    }


    public Item toItem(){
        return Item.builder()
                .itemName(itemName)
                .itemPrice(itemPrice)
                .quantity(quantity)
                .totalPrice(getTotalPrice())
                .build();
    }
}
