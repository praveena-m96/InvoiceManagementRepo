package com.Task.InvoiceManagement.Services;

import com.Task.InvoiceManagement.Repository.ContactRepository;
import com.Task.InvoiceManagement.models.Contact;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service

public class ContactService {

    @Autowired
    ContactRepository contactRepository;

    public Contact getContactByEmail(String contactEmail){
        return contactRepository.findByContactEmail(contactEmail);
    }

    public Contact addContact(Contact contact) {
        return contactRepository.save(contact);
    }
}
