package com.Task.InvoiceManagement.Services;


import com.Task.InvoiceManagement.Repository.InvoiceRepository;
import com.Task.InvoiceManagement.models.Contact;
import com.Task.InvoiceManagement.models.Invoice;
import com.Task.InvoiceManagement.models.InvoiceStatus;
import com.Task.InvoiceManagement.models.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.UUID;

@Service
@Component

public class InvoiceService {

    @Autowired
    InvoiceRepository invoiceRepository;

    @Autowired
    ContactService contactService;

    @Autowired
    ItemService itemService;




    @Transactional
    public String addInvoice(int itemId,String contactEmail,Invoice invoice) throws Exception{

        Contact contact = contactService.getContactByEmail(contactEmail);

        if(contact == null)
            return "Customer Detail is not available to Send Invoice";

        Item item = itemService.getItemByID(itemId);


         invoice = Invoice.builder()
                .invoiceNumber(UUID.randomUUID().toString())
                .invoiceStatus(InvoiceStatus.UNPAID)
                .dueOn(invoice.getDueOn())
                .amountPaid(invoice.getAmountPaid())
                .contact(contact)
                .item(item)
                .build();


        try{
           invoiceRepository.save(invoice);
           double amount=invoice.getAmountPaid();
           double total=item.getTotalPrice();
           if(amount>=total)
               invoice.setInvoiceStatus(InvoiceStatus.PAID);
           else
               invoice.setInvoiceStatus(InvoiceStatus.UNPAID);

           item.setContact(contact);
           itemService.addOrUpdateItem(item);
           invoiceRepository.save(invoice);
       }
       catch(Exception exception){
           invoice.setInvoiceStatus(InvoiceStatus.FAILED);
           invoiceRepository.save(invoice);
            throw new Exception("InvoiceNumber" + invoice.getInvoiceNumber() + " has failed.");
       }

       return invoice.getInvoiceNumber();

    }

}
