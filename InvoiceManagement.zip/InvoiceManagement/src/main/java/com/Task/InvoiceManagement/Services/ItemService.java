package com.Task.InvoiceManagement.Services;

import com.Task.InvoiceManagement.Repository.ItemRepository;
import com.Task.InvoiceManagement.Request.ItemCreateRequest;
import com.Task.InvoiceManagement.models.Contact;
import com.Task.InvoiceManagement.models.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service

public class ItemService {

    @Autowired
    ItemRepository itemRepository;

    @Autowired
    ContactService contactService;


    @Transactional
    public void addItem(ItemCreateRequest itemCreateRequest){
        Item item = itemCreateRequest.toItem();
       Contact contact = contactService.getContactByEmail(itemCreateRequest.getContactEmail());

        if (contact == null) {
            contact = Contact.builder()
                    .contactEmail(itemCreateRequest.getContactEmail())
                    .contactAddress(itemCreateRequest.getContactAddress())
                    .contactCompany(itemCreateRequest.getContactCompany())
                    .contactName(itemCreateRequest.getContactName())
                    .contactNumber(itemCreateRequest.getContactNumber())
                    .vendorAddress(itemCreateRequest.getVendorAddress())
                    .vendorCompany(itemCreateRequest.getVendorCompany())
                    .vendorName(itemCreateRequest.getVendorName())
                    .build();

                     contactService.addContact(contact);
        }
        item.setContact(contact);

        itemRepository.save(item);


    }
    public Item getItemByID(int id) {
        return itemRepository.findById(id).orElse(null);

    }

    public void addOrUpdateItem(Item item) {
        itemRepository.save(item);
    }


    }
