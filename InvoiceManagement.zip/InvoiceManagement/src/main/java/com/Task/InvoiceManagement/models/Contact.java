package com.Task.InvoiceManagement.models;


import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
public class Contact {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String contactName;
    private String contactCompany;
    private String contactAddress;

    private String contactNumber;
    private String vendorName;
    private String vendorCompany;
    private String vendorAddress;

    @Column(unique = true, nullable = false)
    private String contactEmail;



}
