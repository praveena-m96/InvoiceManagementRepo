package com.Task.InvoiceManagement.models;


import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.stereotype.Service;


import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
@Service

public class Invoice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(unique = true, nullable = false)
    private String invoiceNumber;
    private String dueOn;
    @CreationTimestamp
    private Date invoiceDate;
    private double amountPaid;

    @Enumerated(value = EnumType.STRING)
    private InvoiceStatus invoiceStatus;

    @ManyToOne
    private Contact contact;
    @ManyToOne
    private Item item;



}
