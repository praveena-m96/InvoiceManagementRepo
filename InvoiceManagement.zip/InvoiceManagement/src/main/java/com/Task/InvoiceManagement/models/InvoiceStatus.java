package com.Task.InvoiceManagement.models;

public enum InvoiceStatus {
    PAID,
    UNPAID,
    FAILED
}
