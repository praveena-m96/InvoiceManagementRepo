package com.Task.InvoiceManagement.models;


import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder

public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String itemName;
    private double itemPrice;
    private int quantity;
    private double totalPrice;

    @ManyToOne
    private Contact contact;



}
