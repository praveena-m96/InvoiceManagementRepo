package com.Task.InvoiceManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvoiceManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
